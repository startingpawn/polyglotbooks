
C21-C22 Centre Game V1.0 / (c) startingpawn.com

This package contains Polyglot opening books (.bin) for chess engines and GUI front-Ends. 

Any software that supports the Polyglot book format. 

The books store opening trees and move weights, all moves are filtered and weighted equally.



Disclaimer

Without warranties. Use at your own risk.



License & Use

- Free for private use.

- Redistribution: Not permitted. Do not re-host, share, mirror, or publicly distribute originals or derivatives.

- Commercial use: Not permitted. No use within paid products/services, trainings, tournaments, or any commercial context.

- Modifications: Allowed for personal/internal use only; no distribution of modified versions; no commercialization.



Support

Email: info@startingpawn.com

FAQ & updates: startingpawn.com




