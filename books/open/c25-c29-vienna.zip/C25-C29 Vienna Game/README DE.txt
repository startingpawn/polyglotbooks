
C25-C29 Wiener Partie V1.0 / (c) startingpawn.com

Dieses Paket enthält Polyglot-Eröffnungsbücher (.bin) für Schach-Engines und GUI-Frontends.

Kompatibel mit jeder Software, die das Polyglot-Buchformat unterstützt.

Die Bücher speichern Eröffnungsbäume und Zuggewichte; alle Züge sind gefiltert und gleich gewichtet.



Haftungsausschluss

Ohne Gewährleistungen. Nutzung auf eigenes Risiko.



Lizenz & Nutzung

- Kostenlos für die private Nutzung.

- Weitergabe nicht gestattet. Kein Re-Hosting oder öffentliches Verteilen – weder der Originaldateien noch abgeleiteter Werke.

- Keine Verwendung in entgeltlichen Produkten/Diensten, Trainings, Turnieren oder sonstigen kommerziellen Kontexten.

- Modifikationen: Erlaubt nur für den privaten Gebrauch; keine Weitergabe modifizierter Versionen; keine kommerzielle Verwertung.



Support

E-Mail: info@startingpawn.com

FAQ & Updates: startingpawn.com


